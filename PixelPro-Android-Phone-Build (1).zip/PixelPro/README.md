# PixelPro Photo Editor — Android starter project

A native Kotlin Android starter project with an original dark/purple UI. This is a working foundation, not a feature-complete replacement for the referenced commercial editor.

## Implemented in this starter
- Open an image using Android's system photo picker.
- Live brightness, contrast, and saturation preview.
- Quick looks: Original, Mono, Sepia, Vivid.
- Basic undo/redo image-state snapshots.
- Export a high-quality JPEG to `Pictures/PixelPro`.
- Dark editor interface.

## Build an APK using only an Android phone
This project includes a GitHub Actions workflow at `.github/workflows/android.yml`.

1. On your phone, open **github.com** in Chrome and sign in (or create a GitHub account).
2. Create a new repository. You can name it `PixelPro` and choose **Private** or **Public**.
3. Extract this ZIP on your phone using your file manager or an archive app.
4. Upload the *contents* of the extracted `PixelPro` folder to the repository's `main` branch. Make sure the `.github/workflows/android.yml` file is included. GitHub's website may hide dot-folders in some upload flows; if so, use GitHub's web editor to create the file at `.github/workflows/android.yml` and paste the workflow contents from this project.
5. Open the repository's **Actions** tab. Select **Build PixelPro APK** and tap **Run workflow** (or wait for the automatic build after pushing to `main`).
6. When the run finishes successfully, open that run and scroll to **Artifacts**. Download `PixelPro-debug-apk`, then extract it to get `app-debug.apk`.
7. Open the APK on your phone and allow installation from that source if Android asks. Only install APKs from a repository you control.

If the build fails, open the failed run, copy the first red error section, and share it so the project can be corrected.

## Build on a computer
Open this folder in Android Studio, allow Gradle sync, install Android SDK Platform 35 if prompted, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Planned modules for broader feature coverage
Crop, perspective, rotate/flip, resize; curves, levels and HSL; blur/sharpen/denoise; text, stickers, shapes and drawing layers; clone/heal and background removal; batch processing and GIF/PDF/WebP export. These are not implemented in this starter yet.

## Technical notes
- Package: `com.pixelpro.editor`
- Min SDK: 26 (Android 8.0)
- Target/compile SDK: 35
- Android Gradle Plugin: 8.7.3; Kotlin plugin: 2.0.21
- Build workflow uses JDK 17 and Gradle 8.9.
