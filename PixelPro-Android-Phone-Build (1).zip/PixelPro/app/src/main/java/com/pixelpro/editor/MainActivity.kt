package com.pixelpro.editor

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStream
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var emptyState: LinearLayout
    private lateinit var controls: LinearLayout
    private lateinit var valueLabel: TextView
    private var original: Bitmap? = null
    private var working: Bitmap? = null
    private var brightness = 0f
    private var contrast = 1f
    private var saturation = 1f
    private var activeTool = "Brightness"
    private val undoStack = ArrayDeque<Bitmap>()
    private val redoStack = ArrayDeque<Bitmap>()
    private var filter = "Original"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 13, 20)
        window.navigationBarColor = Color.rgb(11, 13, 20)
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun bg(color: Int, radius: Float = 18f): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun button(label: String, primary: Boolean = false, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(15), dp(11), dp(15), dp(11)); background = bg(if (primary) Color.rgb(111, 91, 235) else Color.rgb(35, 39, 54), 14f)
        setOnClickListener { action() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(10)); setBackgroundColor(Color.rgb(11, 13, 20)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        brand.addView(text("PIXELPRO", 20f, Color.WHITE, true)); brand.addView(text("PHOTO STUDIO  ·  EDITOR", 9f, Color.rgb(151, 155, 178), true))
        header.addView(brand)
        header.addView(button("↶", action = { undo() }))
        val gap = View(this); header.addView(gap, LinearLayout.LayoutParams(dp(8), 1))
        header.addView(button("↷", action = { redo() }))
        header.addView(button("Save", true) { saveImage() }.apply { layoutParams = LinearLayout.LayoutParams(-2, -2).also { it.marginStart = dp(8) } })
        root.addView(header)

        val stage = FrameLayout(this).apply {
            background = bg(Color.rgb(22, 25, 37), 22f)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f).also { it.topMargin = dp(18); it.bottomMargin = dp(16) }
        }
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        stage.addView(preview, FrameLayout.LayoutParams(-1, -1))
        emptyState = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val glyph = TextView(this).apply { text = "✦"; textSize = 48f; setTextColor(Color.rgb(160, 145, 255)); gravity = Gravity.CENTER }
        emptyState.addView(glyph)
        emptyState.addView(text("Your next masterpiece starts here", 16f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        emptyState.addView(text("Choose a photo to begin editing", 12f, Color.rgb(151, 155, 178)).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(16)) })
        emptyState.addView(button("＋  Open photo", true) { openPicker() })
        stage.addView(emptyState, FrameLayout.LayoutParams(-1, -1))
        root.addView(stage)

        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(Color.rgb(22, 25, 37), 20f); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        controls.addView(text("ADJUSTMENTS", 10f, Color.rgb(155, 148, 207), true))
        valueLabel = text("Brightness   0", 13f, Color.WHITE, true)
        controls.addView(valueLabel)
        val seek = SeekBar(this).apply { max = 200; progress = 100; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) updateAdjustment(progress) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { pushUndo() }
        }) }
        controls.addView(seek)
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) }
        listOf("Brightness", "Contrast", "Saturation").forEach { name ->
            tools.addView(button(name, name == activeTool) { activeTool = name; valueLabel.text = "$name   ${currentValue()}"; seek.progress = when(name) { "Brightness" -> (brightness * 100 + 100).roundToInt(); "Contrast" -> (contrast * 100).roundToInt(); else -> (saturation * 100).roundToInt() } }, LinearLayout.LayoutParams(0, -2, 1f).also { it.marginEnd = dp(5) })
        }
        controls.addView(tools)
        root.addView(controls)

        val filterTitle = text("QUICK LOOKS", 10f, Color.rgb(155, 148, 207), true).apply { setPadding(dp(2), dp(14), 0, dp(7)) }
        root.addView(filterTitle)
        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Original", "Mono", "Sepia", "Vivid").forEach { f -> filters.addView(button(f, false) { applyFilter(f) }, LinearLayout.LayoutParams(0, -2, 1f).also { it.marginEnd = dp(6) }) }
        root.addView(filters)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
        bottom.addView(text("Edit  ·  Effects  ·  Export", 11f, Color.rgb(120, 125, 150)))
        bottom.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bottom.addView(button("＋ Add photo", false) { openPicker() })
        root.addView(bottom)
        setContentView(root)
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        startActivityForResult(Intent.createChooser(intent, "Choose a photo"), 1001)
    }

    @Deprecated("Legacy activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) data?.data?.let { loadImage(it) }
    }

    private fun loadImage(uri: Uri) {
        try {
            contentResolver.openInputStream(uri).use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream) ?: throw IllegalStateException("Unsupported image")
                original = bitmap.copy(Bitmap.Config.ARGB_8888, true); working = original!!.copy(Bitmap.Config.ARGB_8888, true)
            }
            undoStack.clear(); redoStack.clear(); brightness = 0f; contrast = 1f; saturation = 1f; filter = "Original"
            showBitmap(); emptyState.visibility = View.GONE; preview.visibility = View.VISIBLE
            Toast.makeText(this, "Photo ready to edit", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Could not open this photo", Toast.LENGTH_LONG).show() }
    }

    private fun showBitmap() { preview.setImageBitmap(working); preview.colorFilter = null }
    private fun currentValue(): Int = when(activeTool) { "Brightness" -> (brightness * 100).roundToInt(); "Contrast" -> (contrast * 100).roundToInt(); else -> (saturation * 100).roundToInt() }

    private fun updateAdjustment(progress: Int) {
        val v = (progress - 100) / 100f
        when(activeTool) { "Brightness" -> brightness = v; "Contrast" -> contrast = progress / 100f; else -> saturation = progress / 100f }
        valueLabel.text = "$activeTool   ${currentValue()}"
        renderPreview()
    }

    private fun renderPreview() {
        val base = working ?: original ?: return
        val matrix = ColorMatrix().apply { setSaturation(saturation) }
        val c = contrast; val b = brightness * 255f
        val adjust = ColorMatrix(floatArrayOf(c,0f,0f,0f,b, 0f,c,0f,0f,b, 0f,0f,c,0f,b, 0f,0f,0f,1f,0f))
        matrix.postConcat(adjust)
        when(filter) {
            "Mono" -> matrix.postConcat(ColorMatrix().apply { setSaturation(0f) })
            "Sepia" -> matrix.postConcat(ColorMatrix(floatArrayOf(.393f,.769f,.189f,0f,0f, .349f,.686f,.168f,0f,0f, .272f,.534f,.131f,0f,0f, 0f,0f,0f,1f,0f)))
            "Vivid" -> matrix.postConcat(ColorMatrix().apply { setSaturation(1.5f) })
        }
        preview.setImageBitmap(base)
        preview.colorFilter = ColorMatrixColorFilter(matrix)
    }

    private fun applyFilter(name: String) { pushUndo(); filter = name; renderPreview() }
    private fun pushUndo() { val b = working ?: return; if (undoStack.size >= 12) undoStack.removeFirst(); undoStack.addLast(b.copy(Bitmap.Config.ARGB_8888, true)); redoStack.clear() }
    private fun undo() { if (undoStack.isEmpty()) return; working?.let { redoStack.addLast(it.copy(Bitmap.Config.ARGB_8888, true)) }; working = undoStack.removeLast(); filter = "Original"; brightness = 0f; contrast = 1f; saturation = 1f; showBitmap() }
    private fun redo() { if (redoStack.isEmpty()) return; working?.let { undoStack.addLast(it.copy(Bitmap.Config.ARGB_8888, true)) }; working = redoStack.removeLast(); showBitmap() }

    private fun saveImage() {
        val bitmap = working ?: run { Toast.makeText(this, "Open a photo first", Toast.LENGTH_SHORT).show(); return }
        try {
            val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(output); val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = preview.colorFilter }
            canvas.drawBitmap(bitmap, 0f, 0f, paint)
            val values = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, "PixelPro_${System.currentTimeMillis()}.jpg"); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PixelPro") }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("Storage unavailable")
            contentResolver.openOutputStream(uri).use { stream: OutputStream? -> if (!output.compress(Bitmap.CompressFormat.JPEG, 95, stream)) throw IllegalStateException("Export failed") }
            Toast.makeText(this, "Saved to Pictures/PixelPro", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Could not save image", Toast.LENGTH_LONG).show() }
    }
}
